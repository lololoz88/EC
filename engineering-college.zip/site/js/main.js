'use strict';

const $ = (sel, root = document) => root.querySelector(sel);
const $$ = (sel, root = document) => [...root.querySelectorAll(sel)];

/* ---------- Generic form validation ---------- */
function initForm(form, validators, onValid) {
  const names = Object.keys(validators);
  const field = (n) => form.querySelector(`[data-field="${n}"]`);
  const value = (n) => {
    const el = form.elements[n];
    if (!el) return '';
    return el.type === 'checkbox' ? (el.checked ? '1' : '') : el.value || '';
  };

  function check(n) {
    const msg = validators[n](value(n), value);
    const wrap = field(n);
    wrap.dataset.state = msg ? 'invalid' : 'valid';
    $('.field-error', wrap).textContent = msg;
    $$('input, select, textarea', wrap).forEach((c) => {
      c.setAttribute('aria-invalid', msg ? 'true' : 'false');
      c.classList.toggle('is-invalid', Boolean(msg));
      c.classList.toggle('is-valid', !msg);
    });
    return !msg;
  }

  form.addEventListener('focusout', (e) => {
    const wrap = e.target.closest('[data-field]');
    if (wrap && !wrap.contains(e.relatedTarget)) check(wrap.dataset.field);
  });

  form.addEventListener('input', (e) => {
    const wrap = e.target.closest('[data-field]');
    if (!wrap) return;
    if (wrap.dataset.state) check(wrap.dataset.field);
    if (wrap.dataset.field === 'password' && field('confirm')?.dataset.state) check('confirm');
  });

  form.addEventListener('submit', (e) => {
    e.preventDefault();
    const bad = names.filter((n) => !check(n));
    const summary = $('[data-summary]', form);
    if (bad.length) {
      summary.hidden = false;
      summary.textContent = `Please fix ${bad.length} ${bad.length === 1 ? 'field' : 'fields'} before submitting.`;
      $('input, select, textarea', field(bad[0])).focus();
      return;
    }
    summary.hidden = true;
    onValid(value);
  });

  return function reset() {
    form.reset();
    $$('[data-field]', form).forEach((w) => {
      delete w.dataset.state;
      $$('input, select, textarea', w).forEach((c) => {
        c.removeAttribute('aria-invalid');
        c.classList.remove('is-valid', 'is-invalid');
      });
    });
  };
}

/* ---------- Registration ---------- */
function initRegistration() {
  const form = $('#reg-form');
  if (!form) return;

  const tomorrow = new Date(Date.now() + 864e5).toISOString().slice(0, 10);
  form.elements.intake.min = tomorrow;

  const validators = {
    fullName: (v) => v.trim().length < 2
      ? 'Enter your full name (at least 2 characters).'
      : /^[\p{L}\s'.-]+$/u.test(v.trim()) ? '' : 'Use letters, spaces, apostrophes or hyphens only.',
    email: (v) => /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v.trim()) ? '' : 'Enter a valid email, for example name@example.com.',
    phone: (v) => /^\+?[0-9\s\-()]{9,16}$/.test(v.trim()) ? '' : 'Enter a phone number with 9–15 digits, for example +996 555 123 456.',
    program: (v) => v ? '' : 'Choose the program you want to study.',
    intake: (v) => !v ? 'Choose the date you plan to start.' : v < tomorrow ? 'Choose a date in the future.' : '',
    mode: (v) => v ? '' : 'Choose how you want to study.',
    password: (v) => /^(?=.*[A-Za-z])(?=.*\d).{8,}$/.test(v) ? '' : 'Use at least 8 characters, including a letter and a number.',
    confirm: (v, get) => !v ? 'Repeat your password.' : v === get('password') ? '' : 'Passwords do not match.',
    terms: (v) => v ? '' : 'Accept the privacy policy and terms to continue.',
  };

  const box = $('#confirmation');
  const reset = initForm(form, validators, (get) => {
    $('#conf-name').textContent = get('fullName').trim();
    $('#conf-email').textContent = get('email').trim();
    form.hidden = true;
    box.hidden = false;
    box.focus();
  });

  $('#again').addEventListener('click', () => {
    reset();
    box.hidden = true;
    form.hidden = false;
    form.elements.fullName.focus();
  });
}

/* ---------- Contact ---------- */
function initContact() {
  const form = $('#contact-form');
  if (!form) return;

  const result = $('#form-result');
  let answer = 7;
  const newQuestion = () => {
    const a = 2 + Math.floor(Math.random() * 8);
    const b = 2 + Math.floor(Math.random() * 8);
    answer = a + b;
    $('#math-q').textContent = `${a} + ${b}`;
  };
  newQuestion();

  const validators = {
    name: (v) => v.trim().length >= 2 ? '' : 'Enter your name.',
    email: (v) => /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v.trim()) ? '' : 'Enter a valid email, for example name@example.com.',
    subject: (v) => v.trim().length >= 3 ? '' : 'Enter a subject (at least 3 characters).',
    message: (v) => v.trim().length >= 10 ? '' : 'Write a message of at least 10 characters.',
    check: (v) => Number(v.trim()) === answer && v.trim() !== '' ? '' : 'Incorrect answer. Solve the sum to show you are not a bot.',
  };

  const show = (type, title, text) => {
    result.className = `alert alert-${type}`;
    result.innerHTML = '';
    const h = document.createElement('strong');
    h.textContent = title;
    result.append(h, ' ', text);
    result.hidden = false;
    result.focus();
  };

  const reset = initForm(form, validators, () => {
    if (form.elements.website.value) {
      show('danger', 'Message not sent.', 'Your submission was flagged as spam. Please try again.');
      return;
    }
    show('success', 'Message sent.', `Thank you, ${form.elements.name.value.trim()}. We will reply within two working days.`);
    reset();
    newQuestion();
  });
}

/* ---------- Interaction 1: category filter (Student life) ---------- */
function initFilters() {
  const group = $('[data-filters]');
  if (!group) return;
  group.hidden = false;
  const items = $$('[data-category]');
  const count = $('#result-count');
  group.addEventListener('click', (e) => {
    const btn = e.target.closest('button[data-filter]');
    if (!btn) return;
    $$('button', group).forEach((b) => b.setAttribute('aria-pressed', String(b === btn)));
    let n = 0;
    items.forEach((it) => {
      const show = btn.dataset.filter === 'all' || it.dataset.category === btn.dataset.filter;
      it.hidden = !show;
      if (show) n++;
    });
    count.textContent = `Showing ${n} ${n === 1 ? 'item' : 'items'}`;
  });
}

/* ---------- Interaction 2: tuition period toggle (Admissions) ---------- */
function initTuition() {
  const group = $('[data-period]');
  if (!group) return;
  group.hidden = false;
  group.addEventListener('click', (e) => {
    const btn = e.target.closest('button[data-p]');
    if (!btn) return;
    const div = btn.dataset.p === 'semester' ? 2 : 1;
    $$('button', group).forEach((b) => b.setAttribute('aria-pressed', String(b === btn)));
    $$('[data-year]').forEach((td) => {
      td.textContent = '$' + (Number(td.dataset.year) / div).toLocaleString('en-US');
    });
    $('#period-label').textContent = div === 2 ? 'per semester' : 'per year';
  });
}

initRegistration();
initContact();
initFilters();
initTuition();
