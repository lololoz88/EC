# Engineering College — Static Multi-Page Website

Brochure-style, responsive website for a fictional institution, built with HTML5, CSS3, Bootstrap 5.3 and vanilla JavaScript (ES6+). No server-side code and no frameworks.

## Live URL
https://YOUR-USERNAME.github.io/YOUR-REPO-NAME/

## Page map
| Page | File | Purpose |
|---|---|---|
| Home | `index.html` | Hero, highlights, program preview, call to action |
| About / Programs | `programs.html` | Institution overview and six program cards |
| Admissions | `admissions.html` | Overview, application steps, tuition table |
| Student life / News | `student-life.html` | Events, clubs and announcements grid |
| Contact | `contact.html` | Contact details and Contact Us form |
| Registration | `registration.html` | Advanced applicant registration form |

A fixed top navigation bar (collapsible on small screens, `aria-current` on the active page) is shared by all pages.

## Features
- New York–inspired look: taxi-yellow hero, subway-line color coding per page (bullets and headers), city skyline in inline SVG.
- Mobile-first layout using the Bootstrap grid, navbar, cards, tables and form controls.
- Registration form: client-side validation with inline error and success states, password confirmation, required terms checkbox, error summary, focus moved to the first invalid field, and an on-page confirmation state.
- Contact form: required fields, honeypot field plus a randomized arithmetic question as anti-spam, and clear success / failure messages.
- **Extra interaction 1:** category filter on Student life (All / Events / Clubs / News) with a live result count.
- **Extra interaction 2:** Per year / Per semester toggle for the tuition table on Admissions.
- Both interactions are hidden until JavaScript runs; without JavaScript all content remains visible.
- Accessibility: skip link, semantic landmarks, heading hierarchy, labels and `aria-describedby` for every field, visible focus ring, high-contrast palette, reduced-motion support.

## Known limitations
- Forms are front-end only; nothing is sent or stored, and submission is simulated.
- Bootstrap, Bootstrap JS and Google Fonts load from CDNs, so the nav toggle and fonts need an internet connection.
- The site uses no photographs; visuals are CSS and inline SVG.
- Institution details, names and contact data are fictional.

## Attribution / credits
- [Bootstrap 5.3.3](https://getbootstrap.com/) — MIT License
- [Archivo](https://fonts.google.com/specimen/Archivo) and [Source Sans 3](https://fonts.google.com/specimen/Source+Sans+3) — SIL Open Font License, via Google Fonts
- Logo mark and hero drawing: original inline SVG
